const { Splitting } = window;
Splitting();